function out = loadobj(obj)
%LOADOBJ (overloaded)
out = [];
