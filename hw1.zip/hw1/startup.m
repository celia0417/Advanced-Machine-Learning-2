addpath(genpath('/Users/celia/Documents/MATLAB'));
% addtosystempath('/usr/local/Cellar/graphviz/2.38.0/bin');
addpath /Users/celia/Documents/MATLAB/csdp/matlab
addtosystempath('/Users/celia/Documents/MATLAB/csdp/bin');
